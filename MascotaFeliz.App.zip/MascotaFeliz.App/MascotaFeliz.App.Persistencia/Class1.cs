﻿using System;

namespace MascotaFeliz.App.Persistencia
{
    public class Class1
    {
    }
}
