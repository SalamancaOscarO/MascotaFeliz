using System;
namespace MascotaFeliz.App.Dominio
{
    public class Veterinario:Persona
    {
        public string TarjetaProfesional {set;get;}
    }
}