using System;
namespace MascotaFeliz.App.Dominio
{
    public class Dueno:Persona
    {
        public string Correo {get;set;}
    }
}